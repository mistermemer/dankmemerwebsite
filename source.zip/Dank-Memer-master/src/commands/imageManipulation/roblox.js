const { GenericImageCommand } = require('../../models/');

module.exports = new GenericImageCommand({
  triggers: ['roblox'],
  description: 'what a noob'
});
