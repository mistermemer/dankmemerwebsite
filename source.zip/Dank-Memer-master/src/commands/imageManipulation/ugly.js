const { GenericImageCommand } = require('../../models/');

module.exports = new GenericImageCommand({
  triggers: ['ugly', 'uglier'],
  description: 'lol rekt'
});
